# OrgArq_Trabalho2

SOBRE A CRIAÇÃO DO ARQUIVO DE DADOS:

  - 1º é armazenado o número de registros
  - Depois o topo da pilha de registros que foram excluídos
  
